para compilar facil:
gcc -o entrega entrega.c

para correr cada uno de los tests:
entrega < input1.txt
o
entrega < input2.txt
o
entrega < input3.txt

etc...
4 y 5 contienen negativos :D